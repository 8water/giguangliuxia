package cn.zcbigdata.mybits_demo.mapper;

import cn.zcbigdata.mybits_demo.entity.TTeacherTakeLeave;
import cn.zcbigdata.mybits_demo.entity.*;

import java.util.List;

public interface ManagerMapper {

    public Manager mlogin(Manager manager);

    public List<TTeacherTakeLeave> mTeacherTakeLeave(Integer manager_id);

    public int mManagerUpdateTakeLeave(TTeacherTakeLeave tteachertake_leave);
}
