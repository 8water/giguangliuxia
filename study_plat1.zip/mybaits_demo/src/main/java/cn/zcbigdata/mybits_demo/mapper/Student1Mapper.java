package cn.zcbigdata.mybits_demo.mapper;

        import cn.zcbigdata.mybits_demo.entity.*;

        import java.util.List;

public interface Student1Mapper {

    public Student1 slogin(Student1 student);

    public List<THomeWork> sHomeWorkSelectAll(Integer stu_id);

    public THomeWorkSon sHomeWorkSelectSingle(THomeWorkSon thomework_son);

    public int sHomeWorkInsertSingle(THomeWorkSon thomeworkson);

    public int sHomeWorkUpdateSingle(THomeWorkSon thomework_son);

    public int sTakeLeaveInsert(TStudentTakeLeave sTakeLeaveSelect);

    public List<TStudentTakeLeave> sTakeLeaveSelect(Integer stu_id);

    //文件模块
    public List<Filepath> showFiles(Integer studentid);
}
