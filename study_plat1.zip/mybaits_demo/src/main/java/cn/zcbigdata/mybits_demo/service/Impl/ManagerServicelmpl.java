package cn.zcbigdata.mybits_demo.service.Impl;

import cn.zcbigdata.mybits_demo.entity.*;
import cn.zcbigdata.mybits_demo.entity.TTeacherTakeLeave;
import cn.zcbigdata.mybits_demo.mapper.ManagerMapper;
import cn.zcbigdata.mybits_demo.service.ManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Service
public class ManagerServicelmpl implements ManagerService {

    @Autowired
    private ManagerMapper managerMapper;

    //登录模块
    public Manager mlogin(Manager manager, HttpServletRequest request){

        return  managerMapper.mlogin(manager);
    }

    //批假模块
    public List<TTeacherTakeLeave> mTeacherTakeLeave(Integer manager_id){

        return managerMapper.mTeacherTakeLeave(manager_id);
    }

    public int mManagerUpdateTakeLeave(TTeacherTakeLeave tteachertake_leave){
        return managerMapper.mManagerUpdateTakeLeave(tteachertake_leave);
    }

}
