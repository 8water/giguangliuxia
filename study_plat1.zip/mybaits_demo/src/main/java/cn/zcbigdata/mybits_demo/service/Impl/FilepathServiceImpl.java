package cn.zcbigdata.mybits_demo.service.Impl;

import cn.zcbigdata.mybits_demo.entity.Filepath;
import cn.zcbigdata.mybits_demo.mapper.FilepathMapper;
import cn.zcbigdata.mybits_demo.service.FilepathService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FilepathServiceImpl implements FilepathService {
    @Autowired
    private FilepathMapper filepathMapper;


    @Override
    public int insert(String filepath,String uploadname,String uploadtime,Integer uploadid) {
        return this.filepathMapper.insert(filepath,uploadname,uploadtime,uploadid);
    }

    @Override
    public List<Filepath> showFiles(Integer userid) {

        return this.filepathMapper.showFiles(userid);
    }
}
