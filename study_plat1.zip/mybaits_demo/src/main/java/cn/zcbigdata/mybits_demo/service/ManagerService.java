package cn.zcbigdata.mybits_demo.service;

import cn.zcbigdata.mybits_demo.entity.TTeacherTakeLeave;
import cn.zcbigdata.mybits_demo.entity.*;
import javax.servlet.http.HttpServletRequest;
import java.util.List;

public interface ManagerService {

    public Manager mlogin(Manager manager, HttpServletRequest request);

    public List<TTeacherTakeLeave> mTeacherTakeLeave(Integer manager_id);

    public int mManagerUpdateTakeLeave(TTeacherTakeLeave tteachertake_leave);
}
