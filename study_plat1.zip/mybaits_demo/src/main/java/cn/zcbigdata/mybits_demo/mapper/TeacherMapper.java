package cn.zcbigdata.mybits_demo.mapper;

import cn.zcbigdata.mybits_demo.entity.*;

import java.util.List;

public interface TeacherMapper {

    //登录模块
    public Teacher tlogin(Teacher teacher);

    //作业模块
    public List<THomeWork> tHomeWorkSelectAll(Integer teacher_id);

    public List<THomeWorkSon> tHomeWorkSelectSon(String homework_name);

    public THomeWorkSon tHomeWorkSelectMySon(Integer id);

    public int tHomeWorkUpdate(THomeWorkSon thomeworkson);

    public int tHomeWorkInsert(THomeWork thomework);


    //请假模块
    public List<TStudentTakeLeave> tStudentTakeLeave(Integer teacher_id);

    public int tTeacherUpdateTakeLeave(TStudentTakeLeave tstudenttake_leave);

    public int tTakeLeaveInsert(TTeacherTakeLeave tleave);

    public List<TTeacherTakeLeave> tTakeLeaveSelect(Integer teacher_id);


    //文件模块
    public int insert(String filepath, String uploadname,String uploadtime,Integer uploadid);

    public List<Filepath> showFiles(Integer userid);
}
