package cn.zcbigdata.mybits_demo.controller;

import cn.zcbigdata.mybits_demo.Util.ObjtoLayJson;
import cn.zcbigdata.mybits_demo.entity.*;
import cn.zcbigdata.mybits_demo.service.FileService;
import cn.zcbigdata.mybits_demo.service.FilepathService;
import cn.zcbigdata.mybits_demo.service.TeacherService;
import com.google.gson.Gson;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/teacher")
public class TeacherController {

    @Autowired
    private TeacherService teacherService;

    private static final Logger LOGGER = Logger.getLogger(TeacherController.class);//日志
    private static Gson gson = new Gson();

    /**
     * 跳转到登录页面
     * @return
     */
    @RequestMapping("/tlogin")
    public String ttologin(){
        LOGGER.info("Go To tlogin.html");
        return "tlogin";
    }

    @RequestMapping("/thomeworkselectall")
    public String thomeworkselectall(){
        LOGGER.info("Go To teacherHomeWork.html");
        return "teacherHomeWork";
    }

    @RequestMapping("/ttakeleave")
    public String ttakeleave(){
        LOGGER.info("Go To teacherTakeLeave.html");
        return "teacherTakeLeave";
    }
//    @RequestMapping("/download")
//    public String download(){
//        LOGGER.info("Go To teacherClassScheduleDownload.html");
//        return "teacherClassScheduleDownload";
//    }
    @RequestMapping("/thomeworkson")
    public String thomeworkselectson(){
        LOGGER.info("Go To teacherHomeWorkSon.html");
        return "teacherHomeWorkSon";
    }
    @RequestMapping("/thomeworkmyson")
    public String thomeworkselectmyson(){
        LOGGER.info("Go To teacherHomeWorkMySon.html");
        return "teacherHomeWorkMySon";
    }
    @RequestMapping("/tcoursewaremanagement")
    public String tcoursewaremanagement(){
        LOGGER.info("Go To teacherCoursewareManagement.html");
        return "teacherCoursewareManagement";
    }
    @RequestMapping("/tcontent")
    public String tcontent(){
        LOGGER.info("Go To teacherUploadDownload.html");
        return "teacherUploadDownload";
    }

    //登录模块
    @RequestMapping(value="/ttologin", method=RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String ttologin(HttpServletRequest request, Model model){
        String teacher_id = request.getParameter("teacher_id");
        String teacher_password = request.getParameter("teacher_password");
        Integer teacher_idInteger = Integer.valueOf(teacher_id);
        Teacher teacher1 = new Teacher();
        teacher1.setTeacher_id(teacher_idInteger);
        teacher1.setTeacher_password(teacher_password);
        Teacher teacher0 = teacherService.tlogin(teacher1,request);
        LOGGER.info("ttologin接收参数"+" " +teacher0);
        if ((StringUtils.isNotEmpty(teacher_id))&(StringUtils.isNotEmpty(teacher_password))){
            HttpSession session = request.getSession();
            session.setAttribute("Teacher", teacher0);
            LOGGER.info("登录成功");
            return "teacher";
        }else {
            LOGGER.info("登录失败");
            model.addAttribute("message","登录失败，无此用户");
        }
        return "err";
    }


    //作业模块
    @ResponseBody
    @RequestMapping(value="/tHomeWorkSelectAll", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String tHomeWorkSelectAll(HttpServletRequest request, Model model){
        String teacherIdString = request.getParameter("teacher_id");
        Integer teacherIdInteger = 0;
        try {
            teacherIdInteger = DataCheck1.check2(teacherIdString);
        }catch(Exception e) {
            return e.getMessage();
        }
        LOGGER.info("tHomeWorkSelectAll接收参数"+" " +teacherIdInteger);//日志打印
        //if (StringUtils.isNotEmpty(teacherIdString)){
            THomeWork thomework =  new THomeWork();
            thomework.setTeacher_id(teacherIdInteger);
            List<THomeWork> thomeworklist = teacherService.tHomeWorkSelectAll(teacherIdInteger);
            System.out.println(thomeworklist);
            String data = gson.toJson(thomeworklist);
            return data;
        //}
        //String data = "{\"data\":\"teacherID不能为空！\"}";
        //return "data";
    }

    @ResponseBody
    @RequestMapping(value="/tHomeWorkSelectSon", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String tHomeWorkSelectSon(HttpServletRequest request, Model model){
        String homework_nameString = request.getParameter("homework_name");
        LOGGER.info("tHomeWorkSelectSon接收参数"+" " +homework_nameString);//日志打印
        if (StringUtils.isNotEmpty(homework_nameString)){
            THomeWorkSon thomework_son =  new THomeWorkSon();
            thomework_son.setHomework_name(homework_nameString);
            List<THomeWorkSon> thomeworksonlist = teacherService.tHomeWorkSelectSon(homework_nameString);
            System.out.println(thomeworksonlist);
            String data = gson.toJson(thomeworksonlist);
            return data;
        }
        String data = "{\"data\":\"ID不能为空！\"}";
        return "data";
    }

    @ResponseBody
    @RequestMapping(value="/tHomeWorkSelectMySon", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String tHomeWorkSelectMySon(HttpServletRequest request, Model model){
        String IdString = request.getParameter("id");
        Integer IdInteger = Integer.valueOf(IdString);
        THomeWorkSon thomeworkmyson = teacherService.tHomeWorkSelectMySon(IdInteger);
        String data = gson.toJson(thomeworkmyson);
        LOGGER.info("tHomeWorkSelectMySon接收参数"+" " +data);//日志打印
        return data;
    }

    @ResponseBody
    @RequestMapping(value="/tTeacherUpdateHomeWork", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String tTeacherUpdateHomeWork(HttpServletRequest request, Model model){
        String idString = request.getParameter("id");
        Integer idInteger = Integer.parseInt(idString);
        String teacherreplyString = request.getParameter("teacher_reply");
        String flag_reply = "1";
        THomeWorkSon thomeworkson = new THomeWorkSon();
        try {
            Integer flag_reply1 = DataCheck1.check4(flag_reply);
            System.out.println(flag_reply1+"------------");
            thomeworkson.setFlag_reply(flag_reply1);
        }catch(Exception e) {
            return e.getMessage();
        }
        //if (StringUtils.isNotEmpty(IdString)){
            thomeworkson.setTeacher_reply(teacherreplyString);
            System.out.println(thomeworkson.getFlag_reply()+"*****");////////////////
            thomeworkson.setId(idInteger);
            teacherService.tHomeWorkUpdate(thomeworkson);
            String data = gson.toJson(thomeworkson);
            LOGGER.info("tTeacherUpdateHomeWork接收参数"+" " +thomeworkson);//日志打印
            return data;
        //}
        //String data = "{\"data\":\"没有学生的请假信息！\"}";
        //return "data";
    }

    @ResponseBody
    @RequestMapping(value="/tHomeWorkInsert", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String tHomeWorkInsert(HttpServletRequest request, Model model){
        String homework_nameString = request.getParameter("homework_name");
        Date date = new Date();
        String homework_timeString = date.toString();
        HttpSession session = request.getSession();
        Teacher teacher3 = (Teacher)session.getAttribute("Teacher");
        Integer teacherIdInteger = teacher3.getTeacher_id();
        //System.out.println(teacherIdInteger+"====================");
        Integer homework_countInteger = 0;
        if (StringUtils.isNotEmpty(homework_nameString)) {
            THomeWork homework = new THomeWork();
            homework.setHomework_name(homework_nameString);
            homework.setHomework_leave_time(homework_timeString);
            homework.setTeacher_id(teacherIdInteger);
            homework.setHomework_count(homework_countInteger);
            //homework.setFlag_reply(flag_reply);
            LOGGER.info("tHomeWorkInsert接收参数" + " " + homework);//日志打印
            teacherService.tHomeWorkInsert(homework);
            String data = "{\"data\":\"插入成功！\"}";
            return data;
        }
        String data = "{\"data\":\"插入失败！\"}";
        return data;
    }

    //请假模块
    @ResponseBody
    @RequestMapping(value="/tStudentTakeLeave", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String tStudentTakeLeave(HttpServletRequest request, Model model){
        HttpSession session = request.getSession();
        Teacher teacher3 = (Teacher)session.getAttribute("Teacher");
        Integer teacherIdInteger = teacher3.getTeacher_id();
        //if (StringUtils.isNotEmpty(teacherIdString)){
            TStudentTakeLeave tstudenttakeleave =  new TStudentTakeLeave();
            tstudenttakeleave.setTeacher_id(teacherIdInteger);
            List<TStudentTakeLeave> tstudenttakeleavelist = teacherService.tStudentTakeLeave(teacherIdInteger);
            String data = gson.toJson(tstudenttakeleavelist);
            LOGGER.info("tStudentTakeLeave接收参数"+" " +tstudenttakeleavelist);//日志打印
            return data;
        //}
        //String data = "{\"data\":\"没有学生的请假信息！\"}";
        //return "data";
    }

    @ResponseBody
    @RequestMapping(value="/tTeacherUpdateTakeLeave", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String tTeacherUpdateTakeLeave(HttpServletRequest request, Model model){
        String IdString = request.getParameter("id");
        Integer IdInteger = Integer.valueOf(IdString);
        Integer flagInteger = 1;
        if (StringUtils.isNotEmpty(IdString)){
            TStudentTakeLeave tstudenttakeleave =  new TStudentTakeLeave();
            tstudenttakeleave.setId(IdInteger);
            tstudenttakeleave.setFlag(flagInteger);
            teacherService.tTeacherUpdateTakeLeave(tstudenttakeleave);
            String data = gson.toJson(tstudenttakeleave);
            LOGGER.info("tTeacherUpdateTakeLeave接收参数"+" " +tstudenttakeleave);//日志打印
            return data;
        }
        String data = "{\"data\":\"没有学生的请假信息！\"}";
        return "data";
    }

    @ResponseBody
    @RequestMapping(value="/tTakeLeaveInsert", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String tTakeLeaveInsert(HttpServletRequest request, Model model){
        HttpSession session = request.getSession();
        Teacher teacher3 = (Teacher)session.getAttribute("Teacher");
        Integer teacherIdInteger = teacher3.getTeacher_id();
        Integer flagInteger = 0;
        String teacherNameString = request.getParameter("teacher_name");
        String teacherLeaveReasonString = request.getParameter("teacher_leave_reason");
        Date date = new Date();
        String teacherLeaveTimeString = date.toString();
        //if (StringUtils.isNotEmpty(teacherIdString)){
            TTeacherTakeLeave tleave =  new TTeacherTakeLeave();
            tleave.setTeacher_id(teacherIdInteger);
            tleave.setFlag(flagInteger);
            tleave.setTeacher_name(teacherNameString);
            tleave.setTeacher_leave_reason(teacherLeaveReasonString);
            tleave.setTeacher_leave_time(teacherLeaveTimeString);
            teacherService.tTakeLeaveInsert(tleave);
            LOGGER.info("tTeacherUpdateTakeLeave接收参数"+" " +tleave);//日志打印
            String data = gson.toJson(tleave);
            return data;
        //}
        //String data = "{\"data\":\"请假失败！\"}";
        //return "data";
    }
    @ResponseBody
    @RequestMapping(value="/tTakeLeaveSelect", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String tTakeLeaveSelect(HttpServletRequest request, Model model){
        HttpSession session = request.getSession();
        Teacher teacher3 = (Teacher)session.getAttribute("Teacher");
        Integer teacherIdInteger = teacher3.getTeacher_id();
        System.out.println(teacherIdInteger);
        List<TTeacherTakeLeave> tteachertake_leavelist = teacherService.tTakeLeaveSelect(teacherIdInteger);
        String data = gson.toJson(tteachertake_leavelist);
        LOGGER.info("tTeacherUpdateTakeLeave接收参数"+" " +tteachertake_leavelist);//日志打印
        return data;
    }


    //文件模块

    private static final String NULL_FILE = "";

    @Value("${define.nginx.path}")
    private String nginxPath;


    /**
     * 文件上传
     * @param file
     * @return
     */
    @PostMapping("/uploadFile")
    @ResponseBody
    public String singleFileUpload(@RequestParam("file") MultipartFile file, String uploadname,String uploadtime,Integer uploadid, HttpServletRequest request) {
        Date date = new Date();
//        filepath1.setUploadtime(date.toString());
        uploadtime =  date.toString();
        HttpSession session = request.getSession();
        Teacher teacher3 = (Teacher)session.getAttribute("Teacher");
        uploadname = teacher3.getTeacher_name();
        uploadid = teacher3.getTeacher_id();
//        filepath1.setUploadname(teacher3.getTeacher_name());
//        filepath1.setUploadid(teacher3.getTeacher_id());
        /*if (LOGGER.isDebugEnabled()) {
            LOGGER.info("fileName = {}", file.getOriginalFilename());
        }*/
        try {
            if (file == null || NULL_FILE.equals(file.getOriginalFilename())) {
                return "upload failure1";
            }
            teacherService.saveFile(file.getBytes(), nginxPath, file.getOriginalFilename(),uploadname,uploadtime,uploadid);
            //System.out.println("13445");
            LOGGER.info("文件模块接收参数"+" " +uploadname+" "+uploadtime+" "+uploadid);
        } catch (Exception e) {
            //System.out.println("你好");
            e.printStackTrace();//输出异常的原因
            return "upload failure2";
        }
        return "upload success";
    }

    /**
     * 文件批量上传
     * @param files
     * @return
     */
    @PostMapping("/uploadFiles")
    @ResponseBody
    public String multiFileUpload(@RequestParam("file") MultipartFile[] files,String uploadname,String uploadtime,Integer uploadid) {

        /*if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("fileName = {}", files[0].getOriginalFilename());
        }*/
        try {

            for (int i = 0; i < files.length; i++) {
                //check file
                if (NULL_FILE.equals(files[i].getOriginalFilename())) {
                    continue;
                }
                teacherService.saveFile(files[i].getBytes(), nginxPath, files[i].getOriginalFilename(), uploadname,uploadtime,uploadid);
            }
        } catch (Exception e) {
            return "upload failure";
        }
        return "upload success";
    }

    /**
     * 文件查看
     * @param request
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("showFiles")
    public String showFiles(HttpServletRequest request,Integer userid) throws Exception {
        HttpSession session = request.getSession();
        Teacher teacher3 = (Teacher)session.getAttribute("Teacher");
        userid = teacher3.getTeacher_id();
        List<Filepath> filepaths = teacherService.showFiles(userid);
        String[] Parameter = new String[]{"id","filepath","uploadname","uploadtime","uploadid"};
        String jsonString = ObjtoLayJson.ListtoJson(filepaths,Parameter);
        LOGGER.info("文件模块接收参数showFiles"+" " +jsonString);
//        String json = gson.toJson(filepaths);
//        return json;
        return jsonString;
    }

    /**
     * 文件下载
     * @param response
     * @param model
     * @return
     */
    @RequestMapping(value="/download", method=RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String  testDownload(HttpServletRequest request , HttpServletResponse response , Model model) {
        System.out.println("下载模块进来了------------------------");
        String filepath = request.getParameter("filepath");
        System.out.println(nginxPath + filepath + "**************");
        teacherService.download(response,filepath,model);

        //成功后返回成功信息
        model.addAttribute("result","下载成功");
        return "employee/EmployeeDownloadFile";
    }
}
