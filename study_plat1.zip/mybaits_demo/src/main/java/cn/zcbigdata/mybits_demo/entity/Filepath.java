package cn.zcbigdata.mybits_demo.entity;

public class Filepath {
    private Integer id;
    private String filepath;
    private String uploadname;
    private String uploadtime;
    private Integer uploadid;

    public Integer getUploadid() {
        return uploadid;
    }

    public void setUploadid(Integer uploadid) {
        this.uploadid = uploadid;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFilepath() {
        return filepath;
    }

    public void setFilepath(String filepath) {
        this.filepath = filepath == null ? null : filepath.trim();
    }

    public String getUploadname() {
        return uploadname;
    }

    public void setUploadname(String uploadname) {
        this.uploadname = uploadname;
    }

    public String getUploadtime() {
        return uploadtime;
    }

    public void setUploadtime(String uploadtime) {
        this.uploadtime = uploadtime;
    }

    @Override
    public String toString() {
        return "Filepath{" +
                "id=" + id +
                ", filepath='" + filepath + '\'' +
                ", uploadname='" + uploadname + '\'' +
                ", uploadtime='" + uploadtime + '\'' +
                ", uploadid=" + uploadid +
                '}';
    }
}