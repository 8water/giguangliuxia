package cn.zcbigdata.mybits_demo.entity;

public class Filepath1 {
    private String uploadname;
    private String uploadtime;
    private Integer uploadid;

    public Integer getUploadid() {
        return uploadid;
    }

    public void setUploadid(Integer uploadid) {
        this.uploadid = uploadid;
    }

    public String getUploadname() {
        return uploadname;
    }

    public void setUploadname(String uploadname) {
        this.uploadname = uploadname;
    }

    public String getUploadtime() {
        return uploadtime;
    }

    public void setUploadtime(String uploadtime) {
        this.uploadtime = uploadtime;
    }

    @Override
    public String toString() {
        return "Filepath1{" +
                "uploadname='" + uploadname + '\'' +
                ", uploadtime='" + uploadtime + '\'' +
                ", uploadid=" + uploadid +
                '}';
    }
}