package cn.zcbigdata.mybits_demo.service;

import cn.zcbigdata.mybits_demo.entity.*;
import org.springframework.ui.Model;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;


public interface TeacherService {

    public Teacher tlogin(Teacher teacher, HttpServletRequest request);

    public List<THomeWork> tHomeWorkSelectAll(Integer teacher_id);

    public List<THomeWorkSon> tHomeWorkSelectSon(String homework_name);

    public THomeWorkSon tHomeWorkSelectMySon(Integer id);

    public int tHomeWorkUpdate(THomeWorkSon thomeworkson);

    public int tHomeWorkInsert(THomeWork thomework);
    //public int tHomeWorkInsert(HomeWork homework);

    public List<TStudentTakeLeave> tStudentTakeLeave(Integer teacher_id);

    public int tTeacherUpdateTakeLeave(TStudentTakeLeave tstudenttake_leave);

    public int tTakeLeaveInsert(TTeacherTakeLeave tleave);

    public List<TTeacherTakeLeave> tTakeLeaveSelect(Integer teacher_id);

    //文件模块,Filepath
    public int insert(String filepath,String uploadname,String uploadtime,Integer uploadid);

    public List<Filepath> showFiles(Integer userid);

    //File
    public void saveFile(byte[] file, String filePath, String fileName, String uploadname,String uploadtime,Integer uploadid) throws Exception;

    public void download(HttpServletResponse response, String filename, Model model);
}
