package cn.zcbigdata.mybits_demo.controller;

import cn.zcbigdata.mybits_demo.Util.ObjtoLayJson;
import cn.zcbigdata.mybits_demo.entity.*;
import cn.zcbigdata.mybits_demo.service.Student1Service;
import com.google.gson.Gson;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/student1")
public class Student1Controller {
    @Autowired
    private Student1Service student1Service;

    private static final Logger LOGGER = Logger.getLogger(Student1Controller.class);//日志
    private static Gson gson = new Gson();

    /**
     * 跳转到登录页面
     * @return
     */
    @RequestMapping("/slogin")
    public String stologin(){
        LOGGER.info("Go To slogin.html");
        return "slogin";
    }
    @RequestMapping("/shomeworkselectall")
    public String shomeworkselectall(){
        LOGGER.info("Go To studentHomeWork.html");
        return "studentHomeWork";
    }
    @RequestMapping("/stakeleave")
    public String stakeleave(){
        LOGGER.info("Go To studentTakeLeave.html");
        return "studentTakeLeave";
    }
//    @RequestMapping("/download")
//    public String download(){
//        LOGGER.info("Go To studentDownload.html");
//        return "studentDownload";
//    }

    @RequestMapping("/studentwritehomeworkson")
    public String studentwritehomeworkson(){
        LOGGER.info("Go To studentWriteHomeWorkSon.html");
        return "studentWriteHomeWorkSon";
    }
    @RequestMapping("/scontent")
    public String scontent(){
        LOGGER.info("Go To studentDownload.html");
        return "studentDownload";
    }

    //登录模块
    @RequestMapping(value="/stologin", method=RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String stologin(HttpServletRequest request, Model model){
        String stu_id = request.getParameter("stu_id");
        String stu_password = request.getParameter("stu_password");
        Integer stu_idInteger = Integer.valueOf(stu_id);
        Student1 student1 = new Student1();
        student1.setStu_id(stu_idInteger);
        student1.setStu_password(stu_password);
        Student1 student0 = student1Service.slogin(student1,request);
        if ((StringUtils.isNotEmpty(stu_id))&(StringUtils.isNotEmpty(stu_password))){
            HttpSession session = request.getSession();
            //session.setAttribute("stu_id", stu_idInteger);
            session.setAttribute("Student1",student0);
            LOGGER.info("登录成功");
            return "student";
        }else {
            LOGGER.info("登录失败");
            model.addAttribute("message","登录失败，无此用户");
        }
        return "err";
    }

    //作业模块
    @ResponseBody
    @RequestMapping(value="/sHomeWorkSelectAll", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String sHomeWorkSelectAll(HttpServletRequest request, Model model){
        String stuIdString = request.getParameter("stu_id");
        Integer stuIdInteger = 0;
        try {
            stuIdInteger = DataCheck1.check1(stuIdString);
        }catch(Exception e) {
            return e.getMessage();
        }
        LOGGER.info("sHomeWorkSelectAll接收参数"+" "+stuIdInteger);//日志打印
        List<THomeWork> shomeworklist = student1Service.sHomeWorkSelectAll(stuIdInteger);
        String data = gson.toJson(shomeworklist);
        LOGGER.info("sHomeWorkSelectAll接收参数"+" "+data);//日志打印
        return data;
        //}
        //String data = "{\"data\":\"studentID不能为空！\"}";
        //return "data";
    }

    @ResponseBody
    @RequestMapping(value="/sHomeWorkSelectSingle", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String sHomeWorkSelectSingle(HttpServletRequest request, Model model){
        String homeworkNameString = request.getParameter("homework_name");
        String studentIdString = request.getParameter("stu_id");
        Integer studentIdInteger = 0;
        try {
            studentIdInteger = DataCheck1.check1(studentIdString);
        }catch(Exception e) {
            return e.getMessage();
        }
        LOGGER.info("sHomeWorkSelectSingle接收参数"+" "+homeworkNameString+" "+studentIdInteger);
        THomeWorkSon thomeworkson = new THomeWorkSon();
        thomeworkson.setHomework_name(homeworkNameString);
        thomeworkson.setStu_id(studentIdInteger);
        THomeWorkSon thomeworkson1 = student1Service.sHomeWorkSelectSingle(thomeworkson);
        String data = gson.toJson(thomeworkson1);
        LOGGER.info("sHomeWorkSelectSingle接收参数"+" "+data);//日志打印
        return data;
        //String data = "{\"data\":\"ID不能为空！\"}";
        //return "data";
    }

    //教室布置的作业信息学生将其内容添加到数据库
    @ResponseBody
    @RequestMapping(value="/sHomeWorkInsertSingle", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String sHomeWorkInsertSingle(HttpServletRequest request, Model model) {
        String homework_name = request.getParameter("homework_name");
        Integer homeworkcountInteger = 0;
        Integer flag_reply = 0;
        Integer flag_finish = 0;
        String homework_leave_time = request.getParameter("homework_leave_time");
        String teacher_id = request.getParameter("teacher_id");
        Integer teacher_idInteger = Integer.valueOf(teacher_id);
        //String studentNameString = request.getParameter("stu_name");
        String studentIdString = request.getParameter("stu_id");
        Integer studentIdInteger = 0;
        try {
            studentIdInteger = DataCheck1.check1(studentIdString);
        }catch(Exception e) {
            return e.getMessage();
        }
        THomeWorkSon thomeworkson = new THomeWorkSon();
        thomeworkson.setStu_id(studentIdInteger);
        thomeworkson.setHomework_name(homework_name);
        thomeworkson.setHomework_count(homeworkcountInteger);
        thomeworkson.setHomework_leave_time(homework_leave_time);
        thomeworkson.setTeacher_id(teacher_idInteger);
        thomeworkson.setStu_id(studentIdInteger);
        //thomework1.setStu_name(studentNameString);
        thomeworkson.setFlag_reply(flag_reply);
        thomeworkson.setFlag_finish(flag_finish);
        LOGGER.info("thomework1接收参数" + " " + thomeworkson);//日志打印
        int x = student1Service.sHomeWorkInsertSingle(thomeworkson);
        System.out.println("x="+x);
        if (x == 1) {
            String data = gson.toJson(thomeworkson);
            LOGGER.info("sHomeWorkInsertSingle接收参数" + " " + data);//日志打印
            return data;
        }
        String data = "{\"data\":\"学生插入教师布置的数据失败！\"}";
        return data;
    }

    @ResponseBody
    @RequestMapping(value="/sHomeWorkUpdateSingle", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String sHomeWorkUpdateSingle(HttpServletRequest request, Model model){
        //String homeworkcountString = request.getParameter("homework_count");
        String IdString = request.getParameter("id");
        Integer IdInteger = Integer.valueOf(IdString);
        Date date = new Date();
        String homeworkfinishtime = date.toString();
        String homeworkcontentString = request.getParameter("homework_content");
        //Integer flag_finish = 1;
        String flag_finish = "1";
        THomeWorkSon thomeworkson = new THomeWorkSon();
        try {
            Integer flag_finish1 = DataCheck1.check4(flag_finish);
            thomeworkson.setFlag_finish(flag_finish1);
        }catch(Exception e) {
            return e.getMessage();
        }
        thomeworkson.setHomework_content(homeworkcontentString);
        thomeworkson.setHomework_write_time(homeworkfinishtime);
        thomeworkson.setId(IdInteger);
        System.out.println(flag_finish);
        student1Service.sHomeWorkUpdateSingle(thomeworkson);
        System.out.println(thomeworkson);
        String data = "{\"data\":\"作业完成！\"}";
        return data;
    }

    //请假模块
    @ResponseBody
    @RequestMapping(value="/sTakeLeaveInsert", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String sTakeLeaveInsert(HttpServletRequest request, Model model){
        HttpSession session = request.getSession();
        Student1 student3 = (Student1)session.getAttribute("Student1");
        Integer studentIdInteger = student3.getStu_id();
        Integer flagInteger = 0;
        String studentNameString = request.getParameter("stu_name");
        String studentLeaveReasonString = request.getParameter("stu_leave_reason");
        String teacherIdString = request.getParameter("teacher_id");
        Integer teacherIdInteger = Integer.parseInt(teacherIdString);
        Date date = new Date();
        String studentLeaveTimeString = date.toString();
        //if (StringUtils.isNotEmpty(studentIdString)){
        TStudentTakeLeave tstudenttakeleave =  new TStudentTakeLeave();
        tstudenttakeleave.setStu_id(studentIdInteger);
        tstudenttakeleave.setFlag(flagInteger);
        tstudenttakeleave.setStu_name(studentNameString);
        tstudenttakeleave.setTeacher_id(teacherIdInteger);
        tstudenttakeleave.setStu_leave_reason(studentLeaveReasonString);
        tstudenttakeleave.setStu_leave_time(studentLeaveTimeString);
        student1Service.sTakeLeaveInsert(tstudenttakeleave);
        LOGGER.info("tTeacherUpdateTakeLeave接收参数"+" " +tstudenttakeleave);//日志打印
        String data = gson.toJson(tstudenttakeleave) + "{\"data\":\"请假成功！\"}";
        return data;
        //}
        //String data = "{\"data\":\"请假失败！\"}";
        //return data;
    }

    @ResponseBody
    @RequestMapping(value="/sTakeLeaveSelect", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String sTakeLeaveSelect(HttpServletRequest request, Model model){
        HttpSession session = request.getSession();
        Student1 student3 = (Student1)session.getAttribute("Student1");
        Integer studentIdInteger = student3.getStu_id();
        System.out.println(studentIdInteger+"------------------");
        List<TStudentTakeLeave> tstudenttake_leavelist = student1Service.sTakeLeaveSelect(studentIdInteger);
        String data = gson.toJson(tstudenttake_leavelist);
        LOGGER.info("tTeacherUpdateTakeLeave接收参数"+" " +tstudenttake_leavelist);//日志打印
        return data;
    }


    //文件模块
    private static final String NULL_FILE = "";

    @Value("${define.nginx.path}")
    private String nginxPath;

    /**
     * 文件查看
     * @param request
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("showFiles")
    public String showFiles(HttpServletRequest request,Integer studentid) throws Exception {
        HttpSession session = request.getSession();
        Student1 student3 = (Student1)session.getAttribute("Student1");
        studentid = student3.getStu_id();
        List<Filepath> filepaths = student1Service.showFiles(studentid);
        String[] Parameter = new String[]{"id","filepath","uploadname","uploadtime","uploadid"};
        String jsonString = ObjtoLayJson.ListtoJson(filepaths,Parameter);
        LOGGER.info("文件模块接收参数showFiles"+" " +jsonString);
//        String json = gson.toJson(filepaths);
//        return json;
        return jsonString;
    }

    /**
     * 文件下载
     * @param response
     * @param model
     * @return
     */
    @RequestMapping(value="/download", method=RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String  testDownload(HttpServletRequest request , HttpServletResponse response , Model model) {
        System.out.println("下载模块进来了00------------------------");
        String filepath = request.getParameter("filepath");
        System.out.println(nginxPath + filepath + "**************");
        student1Service.download(response,filepath,model);

        //成功后返回成功信息
        model.addAttribute("result","下载成功");
        return "employee/EmployeeDownloadFile";
    }
}
