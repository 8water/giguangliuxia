package cn.zcbigdata.mybits_demo.entity;

public class DataCheck1 {
    private Integer stu_id;
    private Integer teacher_id;
    private Integer flag_reply;
    private Integer flag_finish;
    public static Integer check1(String stu_id) throws Exception{//throws不稳定
        try {
            int x = Integer.parseInt(stu_id);
            return x;
        }catch(Exception e) {
            throw new Exception("学生学号有问题");
        }
    }
    public static Integer check2(String teacher_id) throws Exception{
        try {
            return Integer.parseInt(teacher_id);
        }catch(Exception e) {
            throw new Exception("教师工号有问题");
        }
    }
    public static Integer check3(String flag_reply) throws Exception{
        try {
            Integer x = Integer.parseInt(flag_reply);
            return x;
        }catch(Exception e) {
            throw new Exception("教师回复标志有问题");
        }
    }
    public static Integer check4(String flag_finish) throws Exception{//throws不稳定
        try {
            Integer x = Integer.parseInt(flag_finish);
            return x;
        }catch(Exception e) {
            throw new Exception("学生完成作业标志有问题");
        }
    }

    public Integer getStu_id() {
        return stu_id;
    }

    public void setStu_id(Integer stu_id) {
        this.stu_id = stu_id;
    }

    public Integer getTeacher_id() {
        return teacher_id;
    }

    public void setTeacher_id(Integer teacher_id) {
        this.teacher_id = teacher_id;
    }

    public Integer getFlag_reply() {
        return flag_reply;
    }

    public void setFlag_reply(Integer flag_reply) {
        this.flag_reply = flag_reply;
    }

    public Integer getFlag_finish() {
        return flag_finish;
    }

    public void setFlag_finish(Integer flag_finish) {
        this.flag_finish = flag_finish;
    }

    @Override
    public String toString() {
        return "dataCheck1{" +
                "stu_id=" + stu_id +
                ", teacher_id=" + teacher_id +
                ", flag_reply=" + flag_reply +
                ", flag_finish=" + flag_finish +
                '}';
    }
}
