package cn.zcbigdata.mybits_demo.service;

import cn.zcbigdata.mybits_demo.entity.*;
import org.springframework.ui.Model;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

public interface Student1Service {

//    public Boolean slogin(EasyStudentLogin easystudentlogin, HttpServletRequest request);
    public Student1 slogin(Student1 student, HttpServletRequest request);

    public List<THomeWork> sHomeWorkSelectAll(Integer stu_id);

    public THomeWorkSon sHomeWorkSelectSingle(THomeWorkSon thomework_son);

    public int sHomeWorkInsertSingle(THomeWorkSon thomework_son);

    public int sHomeWorkUpdateSingle(THomeWorkSon thomework_son);

    public int sTakeLeaveInsert(TStudentTakeLeave sTakeLeaveSelect);

    public List<TStudentTakeLeave> sTakeLeaveSelect(Integer stu_id);

    //文件模块,Filepath
    public List<Filepath> showFiles(Integer studentid);

    //File
    public void download(HttpServletResponse response, String filename, Model model);
}
