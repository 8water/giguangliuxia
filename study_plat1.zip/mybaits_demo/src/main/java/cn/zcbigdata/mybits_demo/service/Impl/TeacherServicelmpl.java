package cn.zcbigdata.mybits_demo.service.Impl;

import cn.zcbigdata.mybits_demo.entity.*;
import cn.zcbigdata.mybits_demo.mapper.TeacherMapper;
import cn.zcbigdata.mybits_demo.service.TeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLEncoder;
import java.util.List;

import static org.apache.commons.lang3.CharEncoding.UTF_8;

@Service
public class TeacherServicelmpl implements TeacherService {

    @Autowired
    private TeacherMapper teacherMapper;

    public Teacher tlogin(Teacher teacher, HttpServletRequest request){
        return  teacherMapper.tlogin(teacher);
    }

    //作业模块
    public List<THomeWork> tHomeWorkSelectAll(Integer teacher_id){
        return teacherMapper.tHomeWorkSelectAll(teacher_id);
    }

    public List<THomeWorkSon> tHomeWorkSelectSon(String homework_name){
        return teacherMapper.tHomeWorkSelectSon(homework_name);
    }

    public THomeWorkSon tHomeWorkSelectMySon(Integer id){
        return teacherMapper.tHomeWorkSelectMySon(id);
    }

    public int tHomeWorkUpdate(THomeWorkSon thomeworkson){
        return teacherMapper.tHomeWorkUpdate(thomeworkson);
    }

    public int tHomeWorkInsert(THomeWork thomework){

        return teacherMapper.tHomeWorkInsert(thomework);
    }

    //请假模块
    public List<TStudentTakeLeave> tStudentTakeLeave(Integer teacher_id){
        return teacherMapper.tStudentTakeLeave(teacher_id);
    }

    public int tTeacherUpdateTakeLeave(TStudentTakeLeave tstudenttake_leave){
        return teacherMapper.tTeacherUpdateTakeLeave(tstudenttake_leave);
    }

    public int tTakeLeaveInsert(TTeacherTakeLeave tleave){
        return teacherMapper.tTakeLeaveInsert(tleave);
    }

    public List<TTeacherTakeLeave> tTakeLeaveSelect(Integer teacher_id){
        return teacherMapper.tTakeLeaveSelect(teacher_id);
    }


    //文件模块
    public int insert(String filepath, String uploadname,String uploadtime,Integer uploadid){
        return teacherMapper.insert(filepath,uploadname,uploadtime,uploadid);
    }

    public List<Filepath> showFiles(Integer userid){
        return teacherMapper.showFiles(userid);
    }

    //File
    /**
     * 文件上传
     * @param file
     * @param filePath
     * @param fileName
     * @throws Exception
     */
    @Override
    public void saveFile(byte[] file, String filePath, String fileName,String uploadname,String uploadtime,Integer uploadid) throws Exception{
        File targetFile = new File(filePath);
        if (!targetFile.exists()) {
            targetFile.mkdirs();
        }

//        teacherMapper.insert(filePath,uploadname,uploadtime,uploadid);
        teacherMapper.insert(fileName,uploadname,uploadtime,uploadid);

        FileOutputStream out = new FileOutputStream(filePath + fileName);
        out.write(file);
        out.flush();
        out.close();
    }

    /**
     * 文件下载
     * @param response
     * @param filename
     * @param model
     */
    @Override
    public void download(HttpServletResponse response, String filename, Model model) {
        //待下载文件名
        String fileName = filename;
        //设置为png格式的文件
//        response.setHeader("content-type", "image/png");
//        response.setContentType("application/octet-stream");
//        response.setHeader("Content-Disposition", "attachment; filename=" + fileName);
        response.setContentType("application/force-download");
        response.setCharacterEncoding(UTF_8);
        // 设置下载后的文件名以及header
        response.addHeader("Content-disposition", "attachment;fileName=" + URLEncoder.encode(filename));
        byte[] buff = new byte[1024];
        //创建缓冲输入流
        BufferedInputStream bis = null;
        OutputStream outputStream = null;

        try {
            outputStream = response.getOutputStream();

            //这个路径为待下载文件的路径
            bis = new BufferedInputStream(new FileInputStream(new File("D:/uploadFile/" + fileName )));
            int read = bis.read(buff);

            //通过while循环写入到指定了的文件夹中
            while (read != -1) {
                outputStream.write(buff, 0, buff.length);
                outputStream.flush();
                read = bis.read(buff);
            }
        } catch ( IOException e ) {
            e.printStackTrace();
            //出现异常返回给页面失败的信息
            System.out.println("--------------------------------");
            model.addAttribute("result","下载失败");
        } finally {
            if (bis != null) {
                try {
                    bis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

}
