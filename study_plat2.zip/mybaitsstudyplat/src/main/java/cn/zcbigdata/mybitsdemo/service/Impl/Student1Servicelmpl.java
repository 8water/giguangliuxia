package cn.zcbigdata.mybitsdemo.service.Impl;

import cn.zcbigdata.mybitsdemo.entity.*;
import cn.zcbigdata.mybitsdemo.mapper.Student1Mapper;
import cn.zcbigdata.mybitsdemo.service.Student1Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLEncoder;
import java.util.List;

import static org.apache.commons.lang3.CharEncoding.UTF_8;

@Service
public class Student1Servicelmpl implements Student1Service {

    @Autowired
    private Student1Mapper student1Mapper;

    //登录模块
    public Student1 slogin(Student1 student1, HttpServletRequest request){
        return student1Mapper.slogin(student1);
    }

    //作业模块
    public List<HomeWork> sHomeWorkSelectAll(Integer studentId){
        return student1Mapper.sHomeWorkSelectAll(studentId);
    }

    public HomeWorkSon sHomeWorkSelectSingle(HomeWorkSon thomeworkson){
        return student1Mapper.sHomeWorkSelectSingle(thomeworkson);
    }

    public int sHomeWorkInsertSingle(HomeWorkSon thomeworkson){
        return student1Mapper.sHomeWorkInsertSingle(thomeworkson);
    }

    public int sHomeWorkUpdateSingle(HomeWorkSon thomeworkson){
        return student1Mapper.sHomeWorkUpdateSingle(thomeworkson);
    }

    //请假模块
    public int sTakeLeaveInsert(TakeLeaveStudent sTakeLeaveSelect){
        return student1Mapper.sTakeLeaveInsert(sTakeLeaveSelect);
    }

    public List<TakeLeaveStudent> sTakeLeaveSelect(Integer studentId){

        return student1Mapper.sTakeLeaveSelect(studentId);
    }

    //文件模块
    public List<FilePath> showFiles(Integer studentId){

        return student1Mapper.showFiles(studentId);
    }


    /**
     * 文件下载
     * @param response
     * @param filename
     * @param model
     */
    @Override
    public void download(HttpServletResponse response, String filename, Model model) {
        //待下载文件名
        String fileName = filename;
        //设置为png格式的文件
//        response.setHeader("content-type", "image/png");
//        response.setContentType("application/octet-stream");
//        response.setHeader("Content-Disposition", "attachment; filename=" + fileName);
        response.setContentType("application/force-download");
        response.setCharacterEncoding(UTF_8);
        // 设置下载后的文件名以及header
        response.addHeader("Content-disposition", "attachment;fileName=" + URLEncoder.encode(filename));
        byte[] buff = new byte[1024];
        //创建缓冲输入流
        BufferedInputStream bis = null;
        OutputStream outputStream = null;

        try {
            outputStream = response.getOutputStream();

            //这个路径为待下载文件的路径
            bis = new BufferedInputStream(new FileInputStream(new File("D:/uploadFile/" + fileName )));
            int read = bis.read(buff);

            //通过while循环写入到指定了的文件夹中
            while (read != -1) {
                outputStream.write(buff, 0, buff.length);
                outputStream.flush();
                read = bis.read(buff);
            }
        } catch ( IOException e ) {
            e.printStackTrace();
            //出现异常返回给页面失败的信息
            System.out.println("--------------------------------");
            model.addAttribute("result","下载失败");
        } finally {
            if (bis != null) {
                try {
                    bis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
