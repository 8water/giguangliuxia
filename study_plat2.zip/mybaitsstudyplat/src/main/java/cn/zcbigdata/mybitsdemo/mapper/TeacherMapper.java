package cn.zcbigdata.mybitsdemo.mapper;

import cn.zcbigdata.mybitsdemo.entity.*;

import java.util.List;

public interface TeacherMapper {

    //登录模块
    public Teacher tlogin(Teacher teacher);

    //作业模块
    public List<HomeWork> tHomeWorkSelectAll(Integer teacherId);

    public List<HomeWorkSon> tHomeWorkSelectSon(String homeworkName);

    public HomeWorkSon tHomeWorkSelectMySon(Integer id);

    public int tHomeWorkUpdate(HomeWorkSon thomeworkson);

    public int tHomeWorkInsert(HomeWork thomework);


    //请假模块
    public List<TakeLeaveStudent> tStudentTakeLeave(Integer teacherId);

    public int tTeacherUpdateTakeLeave(TakeLeaveStudent tstudenttakeleave);

    public int tTakeLeaveInsert(TakeLeaveTeacher tleave);

    public List<TakeLeaveTeacher> tTakeLeaveSelect(Integer teacherId);


    //文件模块
    public int insert(String filePath, String uploadName,String uploadTime,Integer uploadId);

    public List<FilePath> showFiles(Integer teacherId);
}
