package cn.zcbigdata.mybitsdemo.service.Impl;

import cn.zcbigdata.mybitsdemo.entity.*;
import cn.zcbigdata.mybitsdemo.entity.TakeLeaveTeacher;
import cn.zcbigdata.mybitsdemo.mapper.ManagerMapper;
import cn.zcbigdata.mybitsdemo.service.ManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Service
public class ManagerServicelmpl implements ManagerService {

    @Autowired
    private ManagerMapper managerMapper;

    //登录模块
    public Manager mlogin(Manager manager, HttpServletRequest request){

        return  managerMapper.mlogin(manager);
    }

    //批假模块
    public List<TakeLeaveTeacher> mTeacherTakeLeave(Integer managerId){

        return managerMapper.mTeacherTakeLeave(managerId);
    }

    public int mManagerUpdateTakeLeave(TakeLeaveTeacher tteachertakeleave){
        return managerMapper.mManagerUpdateTakeLeave(tteachertakeleave);
    }

}
