package cn.zcbigdata.mybitsdemo.entity;

public class HomeWork {
    private Integer id;
    private String homeworkName;
    private Integer homeworkCount;
    private String homeworkLeaveTime;
    private Integer teacherId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getHomeworkName() {
        return homeworkName;
    }

    public void setHomeworkName(String homeworkName) {
        this.homeworkName = homeworkName;
    }

    public Integer getHomeworkCount() {
        return homeworkCount;
    }

    public void setHomeworkCount(Integer homeworkCount) {
        this.homeworkCount = homeworkCount;
    }

    public String getHomeworkLeaveTime() {
        return homeworkLeaveTime;
    }

    public void setHomeworkLeaveTime(String homeworkLeaveTime) {
        this.homeworkLeaveTime = homeworkLeaveTime;
    }

    public Integer getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(Integer teacherId) {
        this.teacherId = teacherId;
    }

    @Override
    public String toString() {
        return "THomeWork{" +
                "id=" + id +
                ", homeworkName='" + homeworkName + '\'' +
                ", homeworkCount=" + homeworkCount +
                ", homeworkLeaveTime='" + homeworkLeaveTime + '\'' +
                ", teacherId=" + teacherId +
                '}';
    }
}
