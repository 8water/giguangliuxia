package cn.zcbigdata.mybitsdemo.mapper;

import cn.zcbigdata.mybitsdemo.entity.*;

import java.util.List;

public interface Student1Mapper {

    //作业模块
    public Student1 slogin(Student1 student);

    //作业模块
    public List<HomeWork> sHomeWorkSelectAll(Integer studentId);

    public HomeWorkSon sHomeWorkSelectSingle(HomeWorkSon thomeworkson);

    public int sHomeWorkInsertSingle(HomeWorkSon thomeworkson);

    public int sHomeWorkUpdateSingle(HomeWorkSon thomeworkson);

    //请假模块
    public int sTakeLeaveInsert(TakeLeaveStudent sTakeLeaveSelect);

    public List<TakeLeaveStudent> sTakeLeaveSelect(Integer studentId);

    //文件模块
    public List<FilePath> showFiles(Integer studentId);
}
