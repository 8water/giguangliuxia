package cn.zcbigdata.mybitsdemo.entity;

public class TakeLeaveTeacher {
    private Integer id;
    private Integer teacherId;
    private String teacherName;
    private String teacherLeaveReason;
    private String teacherLeaveTime;
    private Integer flag;
    private Integer managerId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(Integer teacherId) {
        this.teacherId = teacherId;
    }

    public String getTeacherName() {
        return teacherName;
    }

    public void setTeacherName(String teacherName) {
        this.teacherName = teacherName;
    }

    public String getTeacherLeaveReason() {
        return teacherLeaveReason;
    }

    public void setTeacherLeaveReason(String teacherLeaveReason) {
        this.teacherLeaveReason = teacherLeaveReason;
    }

    public String getTeacherLeaveTime() {
        return teacherLeaveTime;
    }

    public void setTeacherLeaveTime(String teacherLeaveTime) {
        this.teacherLeaveTime = teacherLeaveTime;
    }

    public Integer getFlag() {
        return flag;
    }

    public void setFlag(Integer flag) {
        this.flag = flag;
    }

    public Integer getManagerId() {
        return managerId;
    }

    public void setManagerId(Integer managerId) {
        this.managerId = managerId;
    }

    @Override
    public String toString() {
        return "TTeacherTakeLeave{" +
                "id=" + id +
                ", teacherId=" + teacherId +
                ", teacherName='" + teacherName + '\'' +
                ", teacherLeaveReason='" + teacherLeaveReason + '\'' +
                ", teacherLeaveTime='" + teacherLeaveTime + '\'' +
                ", flag=" + flag +
                ", managerId=" + managerId +
                '}';
    }
}
