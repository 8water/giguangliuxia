package cn.zcbigdata.mybitsdemo.service;

import cn.zcbigdata.mybitsdemo.entity.TakeLeaveTeacher;
import cn.zcbigdata.mybitsdemo.entity.*;
import javax.servlet.http.HttpServletRequest;
import java.util.List;

public interface ManagerService {

    //登录模块
    public Manager mlogin(Manager manager, HttpServletRequest request);

    //请假模块
    public List<TakeLeaveTeacher> mTeacherTakeLeave(Integer managerId);

    public int mManagerUpdateTakeLeave(TakeLeaveTeacher tteachertakeleave);
}
