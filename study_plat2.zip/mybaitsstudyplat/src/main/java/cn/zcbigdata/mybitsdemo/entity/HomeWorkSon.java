package cn.zcbigdata.mybitsdemo.entity;

public class HomeWorkSon {
    private Integer id;
    private String homeworkName;
    private String studentName;
    private String homeworkContent;
    private String teacherReply;
    private Integer flagReply;
    private Integer flagFinish;
    private String homeworkWriteTime;
    private String homeworkLeaveTime;
    private Integer studentId;
    private Integer homeworkCount;
    private Integer teacherId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getHomeworkName() {
        return homeworkName;
    }

    public void setHomeworkName(String homeworkName) {
        this.homeworkName = homeworkName;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getHomeworkContent() {
        return homeworkContent;
    }

    public void setHomeworkContent(String homeworkContent) {
        this.homeworkContent = homeworkContent;
    }

    public String getTeacherReply() {
        return teacherReply;
    }

    public void setTeacherReply(String teacherReply) {
        this.teacherReply = teacherReply;
    }

    public Integer getFlagReply() {
        return flagReply;
    }

    public void setFlagReply(Integer flagReply) {
        this.flagReply = flagReply;
    }

    public Integer getFlagFinish() {
        return flagFinish;
    }

    public void setFlagFinish(Integer flagFinish) {
        this.flagFinish = flagFinish;
    }

    public String getHomeworkWriteTime() {
        return homeworkWriteTime;
    }

    public void setHomeworkWriteTime(String homeworkWriteTime) {
        this.homeworkWriteTime = homeworkWriteTime;
    }

    public String getHomeworkLeaveTime() {
        return homeworkLeaveTime;
    }

    public void setHomeworkLeaveTime(String homeworkLeaveTime) {
        this.homeworkLeaveTime = homeworkLeaveTime;
    }

    public Integer getStudentId() {
        return studentId;
    }

    public void setStudentId(Integer studentId) {
        this.studentId = studentId;
    }

    public Integer getHomeworkCount() {
        return homeworkCount;
    }

    public void setHomeworkCount(Integer homeworkCount) {
        this.homeworkCount = homeworkCount;
    }

    public Integer getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(Integer teacherId) {
        this.teacherId = teacherId;
    }

    @Override
    public String toString() {
        return "THomeWorkSon{" +
                "id=" + id +
                ", homeworkName='" + homeworkName + '\'' +
                ", studentName='" + studentName + '\'' +
                ", homeworkContent='" + homeworkContent + '\'' +
                ", teacherReply='" + teacherReply + '\'' +
                ", flagReply=" + flagReply +
                ", flagFinish=" + flagFinish +
                ", homeworkWriteTime='" + homeworkWriteTime + '\'' +
                ", homeworkLeaveTime='" + homeworkLeaveTime + '\'' +
                ", studentId=" + studentId +
                ", homeworkCount=" + homeworkCount +
                ", teacherId=" + teacherId +
                '}';
    }
}
