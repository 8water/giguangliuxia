package cn.zcbigdata.mybitsdemo.controller;

import cn.zcbigdata.mybitsdemo.entity.*;
import cn.zcbigdata.mybitsdemo.service.ManagerService;
import com.google.gson.Gson;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/manager")
public class ManagerController {

    @Autowired
    private ManagerService managerService;

    private static final Logger LOGGER = Logger.getLogger(ManagerController.class);//日志
    private static Gson gson = new Gson();

    /**
     * 跳转到登录页面
     * @return
     */
    @RequestMapping("/mlogin")
    public String mtologin(){
        LOGGER.info("Go To managerLogin.html");
        return "manager/managerLogin";
    }
    @RequestMapping("/mtakeleave")
    public String mtakeleave(){
        LOGGER.info("Go To managerTakeLeave.html");
        return "manager/managerTakeLeave";
    }

    //登录模块
    @RequestMapping(value="/mtologin", method=RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String mtologin(HttpServletRequest request, Model model){
        String managerId = request.getParameter("managerId");
        String managerPassword = request.getParameter("managerPassword");
        Integer managerIdInteger = Integer.valueOf(managerId);
        Manager manager1 = new Manager();
        manager1.setManagerId(managerIdInteger);
        manager1.setManagerPassword(managerPassword);
        Manager manager0 = managerService.mlogin(manager1,request);
        LOGGER.info("mtologin接收参数"+" " +manager0);
        if ((StringUtils.isNotEmpty(managerId))&(StringUtils.isNotEmpty(managerPassword))){
            HttpSession session = request.getSession();
            session.setAttribute("Manager", manager0);
            LOGGER.info("登录成功");
            return "manager/managerList";
        }else {
            LOGGER.info("登录失败");
            model.addAttribute("message","登录失败，无此用户");
        }
        return "err";
    }


    //请假模块
    @ResponseBody
    @RequestMapping(value="/mTeacherTakeLeave", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String mTeacherTakeLeave(HttpServletRequest request, Model model){
        //System.out.println("你好丫");
        HttpSession session = request.getSession();
        Manager manager3 = (Manager)session.getAttribute("Manager");
        Integer managerIdInteger = manager3.getManagerId();
        //if (StringUtils.isNotEmpty(teacherIdString)){
        TakeLeaveTeacher tteachertakeleave =  new TakeLeaveTeacher();
        tteachertakeleave.setManagerId(managerIdInteger);
        List<TakeLeaveTeacher> tteachertakeleavelist = managerService.mTeacherTakeLeave(managerIdInteger);
        String data = gson.toJson(tteachertakeleavelist);
        LOGGER.info("mTeacherTakeLeave接收参数"+" " +tteachertakeleavelist);//日志打印
        return data;
    }

    @ResponseBody
    @RequestMapping(value="/mManagerUpdateTakeLeave", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String mManagerUpdateTakeLeave(HttpServletRequest request, Model model){
        String IdString = request.getParameter("id");
        Integer IdInteger = Integer.valueOf(IdString);
        Integer flagInteger = 1;
        if (StringUtils.isNotEmpty(IdString)){
            TakeLeaveTeacher tteachertakeleave =  new TakeLeaveTeacher();
            tteachertakeleave.setId(IdInteger);
            tteachertakeleave.setFlag(flagInteger);
            managerService.mManagerUpdateTakeLeave(tteachertakeleave);
            String data = gson.toJson(tteachertakeleave);
            LOGGER.info("mManagerUpdateTakeLeave接收参数"+" " +tteachertakeleave);//日志打印
            return data;
        }
        String data = "{\"data\":\"没有教师的请假信息！\"}";
        return "data";
    }
}