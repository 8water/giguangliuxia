package cn.zcbigdata.mybitsdemo.mapper;

import cn.zcbigdata.mybitsdemo.entity.*;

import java.util.List;

public interface ManagerMapper {
    //登录模块
    public Manager mlogin(Manager manager);

    //请假模块
    public List<TakeLeaveTeacher> mTeacherTakeLeave(Integer managerId);

    public int mManagerUpdateTakeLeave(TakeLeaveTeacher tteachertakeleave);
}
