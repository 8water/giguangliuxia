package cn.zcbigdata.mybitsdemo.service.Impl;

import cn.zcbigdata.mybitsdemo.entity.*;
import cn.zcbigdata.mybitsdemo.mapper.TeacherMapper;
import cn.zcbigdata.mybitsdemo.service.TeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLEncoder;
import java.util.List;

import static org.apache.commons.lang3.CharEncoding.UTF_8;

@Service
public class TeacherServicelmpl implements TeacherService {

    @Autowired
    private TeacherMapper teacherMapper;

    //登录模块
    public Teacher tlogin(Teacher teacher, HttpServletRequest request){
        return  teacherMapper.tlogin(teacher);
    }

    //作业模块
    public List<HomeWork> tHomeWorkSelectAll(Integer teacherId){
        return teacherMapper.tHomeWorkSelectAll(teacherId);
    }

    public List<HomeWorkSon> tHomeWorkSelectSon(String homeworkName){
        return teacherMapper.tHomeWorkSelectSon(homeworkName);
    }

    public HomeWorkSon tHomeWorkSelectMySon(Integer id){
        return teacherMapper.tHomeWorkSelectMySon(id);
    }

    public int tHomeWorkUpdate(HomeWorkSon thomeworkson){
        return teacherMapper.tHomeWorkUpdate(thomeworkson);
    }

    public int tHomeWorkInsert(HomeWork thomework){

        return teacherMapper.tHomeWorkInsert(thomework);
    }

    //请假模块
    public List<TakeLeaveStudent> tStudentTakeLeave(Integer teacherId){
        return teacherMapper.tStudentTakeLeave(teacherId);
    }

    public int tTeacherUpdateTakeLeave(TakeLeaveStudent tstudenttakeleave){
        return teacherMapper.tTeacherUpdateTakeLeave(tstudenttakeleave);
    }

    public int tTakeLeaveInsert(TakeLeaveTeacher tleave){
        return teacherMapper.tTakeLeaveInsert(tleave);
    }

    public List<TakeLeaveTeacher> tTakeLeaveSelect(Integer teacherId){
        return teacherMapper.tTakeLeaveSelect(teacherId);
    }


    //文件模块
    public int insert(String filePath, String uploadName,String uploadTime,Integer uploadId){
        return teacherMapper.insert(filePath,uploadName,uploadTime,uploadId);
    }

    public List<FilePath> showFiles(Integer teacherId){
        return teacherMapper.showFiles(teacherId);
    }

    //File
    /**
     * 文件上传
     * @param file
     * @param filePath
     * @param fileName
     * @throws Exception
     */
    @Override
    public void saveFile(byte[] file, String filePath, String fileName,String uploadName,String uploadTime,Integer uploadId) throws Exception{
        File targetFile = new File(filePath);
        if (!targetFile.exists()) {
            targetFile.mkdirs();
        }

        teacherMapper.insert(fileName,uploadName,uploadTime,uploadId);

        FileOutputStream out = new FileOutputStream(filePath + fileName);
        out.write(file);
        out.flush();
        out.close();
    }

    /**
     * 文件下载
     * @param response
     * @param filename
     * @param model
     */
    @Override
    public void download(HttpServletResponse response, String filename, Model model) {
        //待下载文件名
        String fileName = filename;
        //设置为png格式的文件
//        response.setHeader("content-type", "image/png");
//        response.setContentType("application/octet-stream");
//        response.setHeader("Content-Disposition", "attachment; filename=" + fileName);
        response.setContentType("application/force-download");
        response.setCharacterEncoding(UTF_8);
        // 设置下载后的文件名以及header
        response.addHeader("Content-disposition", "attachment;fileName=" + URLEncoder.encode(filename));
        byte[] buff = new byte[1024];
        //创建缓冲输入流
        BufferedInputStream bis = null;
        OutputStream outputStream = null;

        try {
            outputStream = response.getOutputStream();

            //这个路径为待下载文件的路径
            bis = new BufferedInputStream(new FileInputStream(new File("D:/uploadFile/" + fileName )));
            int read = bis.read(buff);

            //通过while循环写入到指定了的文件夹中
            while (read != -1) {
                outputStream.write(buff, 0, buff.length);
                outputStream.flush();
                read = bis.read(buff);
            }
        } catch ( IOException e ) {
            e.printStackTrace();
            //出现异常返回给页面失败的信息
            System.out.println("--------------------------------");
            model.addAttribute("result","下载失败");
        } finally {
            if (bis != null) {
                try {
                    bis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

}
