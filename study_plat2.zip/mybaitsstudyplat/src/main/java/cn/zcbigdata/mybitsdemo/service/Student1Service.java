package cn.zcbigdata.mybitsdemo.service;

import cn.zcbigdata.mybitsdemo.entity.*;
import org.springframework.ui.Model;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

public interface Student1Service {

    //登录模块
    public Student1 slogin(Student1 student, HttpServletRequest request);

    //作业模块
    public List<HomeWork> sHomeWorkSelectAll(Integer studentId);

    public HomeWorkSon sHomeWorkSelectSingle(HomeWorkSon thomeworkson);

    public int sHomeWorkInsertSingle(HomeWorkSon thomeworkson);

    public int sHomeWorkUpdateSingle(HomeWorkSon thomeworkson);

    //请假模块
    public int sTakeLeaveInsert(TakeLeaveStudent sTakeLeaveSelect);

    public List<TakeLeaveStudent> sTakeLeaveSelect(Integer studentId);

    //文件模块,Filepath
    public List<FilePath> showFiles(Integer studentId);

    //File
    public void download(HttpServletResponse response, String fileName, Model model);
}
