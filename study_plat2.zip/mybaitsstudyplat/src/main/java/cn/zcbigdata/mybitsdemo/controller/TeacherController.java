package cn.zcbigdata.mybitsdemo.controller;

import cn.zcbigdata.mybitsdemo.util.ObjtoLayJson;
import cn.zcbigdata.mybitsdemo.entity.*;
import cn.zcbigdata.mybitsdemo.service.TeacherService;
import com.google.gson.Gson;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/teacher")
public class TeacherController {

    @Autowired
    private TeacherService teacherService;

    private static final Logger LOGGER = Logger.getLogger(TeacherController.class);//日志
    private static Gson gson = new Gson();

    /**
     * 跳转到登录页面
     * @return
     */
    @RequestMapping("/tlogin")
    public String ttologin(){
        LOGGER.info("Go To teacherLogin.html");
        return "teacher/teacherLogin";
    }

    @RequestMapping("/thomeworkselectall")
    public String thomeworkselectall(){
        LOGGER.info("Go To teacherHomeWork.html");
        return "teacher/teacherHomeWork";
    }

    @RequestMapping("/ttakeleave")
    public String ttakeleave(){
        LOGGER.info("Go To teacherTakeLeave.html");
        return "teacher/teacherTakeLeave";
    }
    @RequestMapping("/tcontent")
    public String tcontent(){
        LOGGER.info("Go To teacherUploadDownload.html");
        return "teacher/teacherUploadDownload";
    }

    //登录模块
    @RequestMapping(value="/ttologin", method=RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String ttologin(HttpServletRequest request, Model model){
        String teacherId = request.getParameter("teacherId");
        String teacherPassword = request.getParameter("teacherPassword");
        Integer teacherIdInteger = Integer.valueOf(teacherId);
        Teacher teacher1 = new Teacher();
        teacher1.setTeacherId(teacherIdInteger);
        teacher1.setTeacherPassword(teacherPassword);
        Teacher teacher0 = teacherService.tlogin(teacher1,request);
        LOGGER.info("ttologin接收参数"+" " +teacher0);
        if ((StringUtils.isNotEmpty(teacherId))&(StringUtils.isNotEmpty(teacherPassword))){
            HttpSession session = request.getSession();
            session.setAttribute("Teacher", teacher0);
            LOGGER.info("登录成功");
            return "teacher/teacherList";
        }else {
            LOGGER.info("登录失败");
            model.addAttribute("message","登录失败，无此用户");
        }
        return "err";
    }


    //作业模块
    @ResponseBody
    @RequestMapping(value="/tHomeWorkSelectAll", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String tHomeWorkSelectAll(HttpServletRequest request, Model model){
        String teacherIdString = request.getParameter("teacherId");
        Integer teacherIdInteger = 0;
        try {
            teacherIdInteger = DataCheck1.check2(teacherIdString);
        }catch(Exception e) {
            return e.getMessage();
        }
        LOGGER.info("tHomeWorkSelectAll接收参数"+" " +teacherIdInteger);//日志打印
        //if (StringUtils.isNotEmpty(teacherIdString)){
            HomeWork thomework =  new HomeWork();
            thomework.setTeacherId(teacherIdInteger);
            List<HomeWork> thomeworklist = teacherService.tHomeWorkSelectAll(teacherIdInteger);
            System.out.println(thomeworklist);
            String data = gson.toJson(thomeworklist);
            return data;
        //}
        //String data = "{\"data\":\"teacherID不能为空！\"}";
        //return "data";
    }

    @ResponseBody
    @RequestMapping(value="/tHomeWorkSelectSon", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String tHomeWorkSelectSon(HttpServletRequest request, Model model){
        String homeworkNameString = request.getParameter("homeworkName");
        LOGGER.info("tHomeWorkSelectSon接收参数"+" " +homeworkNameString);//日志打印
        if (StringUtils.isNotEmpty(homeworkNameString)){
            HomeWorkSon thomeworkson =  new HomeWorkSon();
            thomeworkson.setHomeworkName(homeworkNameString);
            List<HomeWorkSon> thomeworksonlist = teacherService.tHomeWorkSelectSon(homeworkNameString);
            System.out.println(thomeworksonlist);
            String data = gson.toJson(thomeworksonlist);
            return data;
        }
        String data = "{\"data\":\"ID不能为空！\"}";
        return "data";
    }

    @ResponseBody
    @RequestMapping(value="/tHomeWorkSelectMySon", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String tHomeWorkSelectMySon(HttpServletRequest request, Model model){
        String IdString = request.getParameter("id");
        Integer IdInteger = Integer.valueOf(IdString);
        HomeWorkSon thomeworkmyson = teacherService.tHomeWorkSelectMySon(IdInteger);
        String data = gson.toJson(thomeworkmyson);
        LOGGER.info("tHomeWorkSelectMySon接收参数"+" " +data);//日志打印
        return data;
    }

    @ResponseBody
    @RequestMapping(value="/tTeacherUpdateHomeWork", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String tTeacherUpdateHomeWork(HttpServletRequest request, Model model){
        String idString = request.getParameter("id");
        Integer idInteger = Integer.parseInt(idString);
        String teacherreplyString = request.getParameter("teacherReply");
        String flagReply = "1";
        HomeWorkSon thomeworkson = new HomeWorkSon();
        try {
            Integer flagReply1 = DataCheck1.check4(flagReply);
            System.out.println(flagReply1+"------------");
            thomeworkson.setFlagReply(flagReply1);
        }catch(Exception e) {
            return e.getMessage();
        }
        //if (StringUtils.isNotEmpty(IdString)){
            thomeworkson.setTeacherReply(teacherreplyString);
            System.out.println(thomeworkson.getFlagReply()+"*****");////////////////
            thomeworkson.setId(idInteger);
            teacherService.tHomeWorkUpdate(thomeworkson);
            String data = gson.toJson(thomeworkson);
            LOGGER.info("tTeacherUpdateHomeWork接收参数"+" " +thomeworkson);//日志打印
            return data;
        //}
        //String data = "{\"data\":\"没有学生的请假信息！\"}";
        //return "data";
    }

    @ResponseBody
    @RequestMapping(value="/tHomeWorkInsert", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String tHomeWorkInsert(HttpServletRequest request, Model model){
        String homeworkNameString = request.getParameter("homeworkName");
        Date date = new Date();
        String homeworkTimeString = date.toString();
        HttpSession session = request.getSession();
        Teacher teacher3 = (Teacher)session.getAttribute("Teacher");
        Integer teacherIdInteger = teacher3.getTeacherId();
        //System.out.println(teacherIdInteger+"====================");
        Integer homeworkCountInteger = 0;
        if (StringUtils.isNotEmpty(homeworkNameString)) {
            HomeWork homework = new HomeWork();
            homework.setHomeworkName(homeworkNameString);
            homework.setHomeworkLeaveTime(homeworkTimeString);
            homework.setTeacherId(teacherIdInteger);
            homework.setHomeworkCount(homeworkCountInteger);
            //homework.setFlag_reply(flag_reply);
            LOGGER.info("tHomeWorkInsert接收参数" + " " + homework);//日志打印
            teacherService.tHomeWorkInsert(homework);
            String data = "{\"data\":\"插入成功！\"}";
            return data;
        }
        String data = "{\"data\":\"插入失败！\"}";
        return data;
    }

    //请假模块
    @ResponseBody
    @RequestMapping(value="/tStudentTakeLeave", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String tStudentTakeLeave(HttpServletRequest request, Model model){
        HttpSession session = request.getSession();
        Teacher teacher3 = (Teacher)session.getAttribute("Teacher");
        Integer teacherIdInteger = teacher3.getTeacherId();
        //if (StringUtils.isNotEmpty(teacherIdString)){
            TakeLeaveStudent tstudenttakeleave =  new TakeLeaveStudent();
            tstudenttakeleave.setTeacherId(teacherIdInteger);
            List<TakeLeaveStudent> tstudenttakeleavelist = teacherService.tStudentTakeLeave(teacherIdInteger);
            String data = gson.toJson(tstudenttakeleavelist);
            LOGGER.info("tStudentTakeLeave接收参数"+" " +tstudenttakeleavelist);//日志打印
            return data;
        //}
        //String data = "{\"data\":\"没有学生的请假信息！\"}";
        //return "data";
    }

    @ResponseBody
    @RequestMapping(value="/tTeacherUpdateTakeLeave", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String tTeacherUpdateTakeLeave(HttpServletRequest request, Model model){
        String IdString = request.getParameter("id");
        Integer IdInteger = Integer.valueOf(IdString);
        Integer flagInteger = 1;
        if (StringUtils.isNotEmpty(IdString)){
            TakeLeaveStudent tstudenttakeleave =  new TakeLeaveStudent();
            tstudenttakeleave.setId(IdInteger);
            tstudenttakeleave.setFlag(flagInteger);
            teacherService.tTeacherUpdateTakeLeave(tstudenttakeleave);
            String data = gson.toJson(tstudenttakeleave);
            LOGGER.info("tTeacherUpdateTakeLeave接收参数"+" " +tstudenttakeleave);//日志打印
            return data;
        }
        String data = "{\"data\":\"没有学生的请假信息！\"}";
        return "data";
    }

    @ResponseBody
    @RequestMapping(value="/tTakeLeaveInsert", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String tTakeLeaveInsert(HttpServletRequest request, Model model){
        HttpSession session = request.getSession();
        Teacher teacher3 = (Teacher)session.getAttribute("Teacher");
        Integer teacherIdInteger = teacher3.getTeacherId();
        Integer flagInteger = 0;
        String teacherNameString = request.getParameter("teacherName");
        String teacherLeaveReasonString = request.getParameter("teacherLeaveReason");
        Date date = new Date();
        String teacherLeaveTimeString = date.toString();
        //if (StringUtils.isNotEmpty(teacherIdString)){
            TakeLeaveTeacher tleave =  new TakeLeaveTeacher();
            tleave.setTeacherId(teacherIdInteger);
            tleave.setFlag(flagInteger);
            tleave.setTeacherName(teacherNameString);
            tleave.setTeacherLeaveReason(teacherLeaveReasonString);
            tleave.setTeacherLeaveTime(teacherLeaveTimeString);
            teacherService.tTakeLeaveInsert(tleave);
            LOGGER.info("tTeacherUpdateTakeLeave接收参数"+" " +tleave);//日志打印
            String data = gson.toJson(tleave);
            return data;
        //}
        //String data = "{\"data\":\"请假失败！\"}";
        //return "data";
    }
    @ResponseBody
    @RequestMapping(value="/tTakeLeaveSelect", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String tTakeLeaveSelect(HttpServletRequest request, Model model){
        HttpSession session = request.getSession();
        Teacher teacher3 = (Teacher)session.getAttribute("Teacher");
        Integer teacherIdInteger = teacher3.getTeacherId();
        System.out.println(teacherIdInteger);
        List<TakeLeaveTeacher> tteachertakeleavelist = teacherService.tTakeLeaveSelect(teacherIdInteger);
        String data = gson.toJson(tteachertakeleavelist);
        LOGGER.info("tTeacherUpdateTakeLeave接收参数"+" " +tteachertakeleavelist);//日志打印
        return data;
    }


    //文件模块

    private static final String NULL_FILE = "";

    @Value("${define.nginx.path}")
    private String nginxPath;


    /**
     * 文件上传
     * @param file
     * @return
     */
    @PostMapping("/uploadFile")
    @ResponseBody
    public String singleFileUpload(@RequestParam("file") MultipartFile file, String uploadName,String uploadTime,Integer uploadId, HttpServletRequest request) {
        Date date = new Date();
//        filepath1.setUploadtime(date.toString());
        uploadTime =  date.toString();
        HttpSession session = request.getSession();
        Teacher teacher3 = (Teacher)session.getAttribute("Teacher");
        uploadName = teacher3.getTeacherName();
        uploadId = teacher3.getTeacherId();
//        filepath1.setUploadname(teacher3.getTeacher_name());
//        filepath1.setUploadid(teacher3.getTeacher_id());
        /*if (LOGGER.isDebugEnabled()) {
            LOGGER.info("fileName = {}", file.getOriginalFilename());
        }*/
        try {
            if (file == null || NULL_FILE.equals(file.getOriginalFilename())) {
                return "upload failure1";
            }
            teacherService.saveFile(file.getBytes(), nginxPath, file.getOriginalFilename(),uploadName,uploadTime,uploadId);
            //System.out.println("13445");
            LOGGER.info("文件模块接收参数"+" " +uploadName+" "+uploadTime+" "+uploadId);
        } catch (Exception e) {
            //System.out.println("你好");
            e.printStackTrace();//输出异常的原因
            return "upload failure2";
        }
        return "upload success";
    }

    /**
     * 文件批量上传
     * @param files
     * @return
     */
    @PostMapping("/uploadFiles")
    @ResponseBody
    public String multiFileUpload(@RequestParam("file") MultipartFile[] files,String uploadName,String uploadTime,Integer uploadId) {

        /*if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("fileName = {}", files[0].getOriginalFilename());
        }*/
        try {

            for (int i = 0; i < files.length; i++) {
                //check file
                if (NULL_FILE.equals(files[i].getOriginalFilename())) {
                    continue;
                }
                teacherService.saveFile(files[i].getBytes(), nginxPath, files[i].getOriginalFilename(), uploadName,uploadTime,uploadId);
            }
        } catch (Exception e) {
            return "upload failure";
        }
        return "upload success";
    }

    /**
     * 文件查看
     * @param request
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("showFiles")
    public String showFiles(HttpServletRequest request,Integer teacherId) throws Exception {
        HttpSession session = request.getSession();
        Teacher teacher3 = (Teacher)session.getAttribute("Teacher");
        teacherId = teacher3.getTeacherId();
        List<FilePath> filePaths = teacherService.showFiles(teacherId);
        String[] Parameter = new String[]{"id","filePath","uploadName","uploadTime","uploadId"};
        String jsonString = ObjtoLayJson.ListtoJson(filePaths,Parameter);
        LOGGER.info("文件模块接收参数showFiles"+" " +jsonString);
//        String json = gson.toJson(filepaths);
//        return json;
        return jsonString;
    }

    /**
     * 文件下载
     * @param response
     * @param model
     * @return
     */
    @RequestMapping(value="/download", method=RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String  testDownload(HttpServletRequest request , HttpServletResponse response , Model model) {
        System.out.println("下载模块进来了------------------------");
        String filePath = request.getParameter("filePath");
        System.out.println(nginxPath + filePath + "**************");
        teacherService.download(response,filePath,model);

        //成功后返回成功信息
        model.addAttribute("result","下载成功");
        return "employee/EmployeeDownloadFile";
    }
}
