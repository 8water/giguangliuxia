package cn.zcbigdata.mybitsdemo.controller;

import cn.zcbigdata.mybitsdemo.util.ObjtoLayJson;
import cn.zcbigdata.mybitsdemo.entity.*;
import cn.zcbigdata.mybitsdemo.service.Student1Service;
import com.google.gson.Gson;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/student1")
public class Student1Controller {
    @Autowired
    private Student1Service student1Service;

    private static final Logger LOGGER = Logger.getLogger(Student1Controller.class);//日志
    private static Gson gson = new Gson();

    /**
     * 跳转到登录页面
     * @return
     */
    @RequestMapping("/slogin")
    public String stologin(){
        LOGGER.info("Go To studentLogin.html");
        return "student/studentLogin";
    }
    @RequestMapping("/shomeworkselectall")
    public String shomeworkselectall(){
        LOGGER.info("Go To studentHomeWork.html");
        return "student/studentHomeWork";
    }
    @RequestMapping("/stakeleave")
    public String stakeleave(){
        LOGGER.info("Go To studentTakeLeave.html");
        return "student/studentTakeLeave";
    }
    @RequestMapping("/scontent")
    public String scontent(){
        LOGGER.info("Go To studentDownload.html");
        return "student/studentDownload";
    }

    //登录模块
    @RequestMapping(value="/stologin", method=RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String stologin(HttpServletRequest request, Model model){
        String studentId = request.getParameter("studentId");
        String studentPassword = request.getParameter("studentPassword");
        Integer studentIdInteger = Integer.valueOf(studentId);
        Student1 student1 = new Student1();
        student1.setStudentId(studentIdInteger);
        student1.setStudentPassword(studentPassword);
        Student1 student0 = student1Service.slogin(student1,request);
        if ((StringUtils.isNotEmpty(studentId))&(StringUtils.isNotEmpty(studentPassword))){
            HttpSession session = request.getSession();
            session.setAttribute("Student1",student0);
            LOGGER.info("登录成功");
            return "student/studentList";
        }else {
            LOGGER.info("登录失败");
            model.addAttribute("message","登录失败，无此用户");
        }
        return "err";
    }

    //作业模块
    @ResponseBody
    @RequestMapping(value="/sHomeWorkSelectAll", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String sHomeWorkSelectAll(HttpServletRequest request, Model model){
        String studentIdString = request.getParameter("studentId");
        Integer studentIdInteger = 0;
        try {
            studentIdInteger = DataCheck1.check1(studentIdString);
        }catch(Exception e) {
            return e.getMessage();
        }
        LOGGER.info("sHomeWorkSelectAll接收参数"+" "+studentIdInteger);//日志打印
        List<HomeWork> shomeworklist = student1Service.sHomeWorkSelectAll(studentIdInteger);
        String data = gson.toJson(shomeworklist);
        LOGGER.info("sHomeWorkSelectAll接收参数"+" "+data);//日志打印
        return data;
        //}
        //String data = "{\"data\":\"studentID不能为空！\"}";
        //return "data";
    }

    @ResponseBody
    @RequestMapping(value="/sHomeWorkSelectSingle", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String sHomeWorkSelectSingle(HttpServletRequest request, Model model){
        String homeworkNameString = request.getParameter("homeworkName");
        String studentIdString = request.getParameter("studentId");
        Integer studentIdInteger = 0;
        try {
            studentIdInteger = DataCheck1.check1(studentIdString);
        }catch(Exception e) {
            return e.getMessage();
        }
        LOGGER.info("sHomeWorkSelectSingle接收参数"+" "+homeworkNameString+" "+studentIdInteger);
        HomeWorkSon thomeworkson = new HomeWorkSon();
        thomeworkson.setHomeworkName(homeworkNameString);
        thomeworkson.setStudentId(studentIdInteger);
        HomeWorkSon thomeworkson1 = student1Service.sHomeWorkSelectSingle(thomeworkson);
        String data = gson.toJson(thomeworkson1);
        LOGGER.info("sHomeWorkSelectSingle接收参数"+" "+data);//日志打印
        return data;
        //String data = "{\"data\":\"ID不能为空！\"}";
        //return "data";
    }

    //教室布置的作业信息学生将其内容添加到数据库
    @ResponseBody
    @RequestMapping(value="/sHomeWorkInsertSingle", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String sHomeWorkInsertSingle(HttpServletRequest request, Model model) {
        String homeworkName = request.getParameter("homeworkName");
        Integer homeworkcountInteger = 0;
        Integer flagReply = 0;
        Integer flagFinish = 0;
        String homeworkLeaveTime = request.getParameter("homeworkLeaveTime");
        String teacherId = request.getParameter("teacherId");
        Integer teacherIdInteger = Integer.valueOf(teacherId);
        String studentIdString = request.getParameter("studentId");
        Integer studentIdInteger = 0;
        try {
            studentIdInteger = DataCheck1.check1(studentIdString);
        }catch(Exception e) {
            return e.getMessage();
        }
        HomeWorkSon thomeworkson = new HomeWorkSon();
        thomeworkson.setStudentId(studentIdInteger);
        thomeworkson.setHomeworkName(homeworkName);
        thomeworkson.setHomeworkCount(homeworkcountInteger);
        thomeworkson.setHomeworkLeaveTime(homeworkLeaveTime);
        thomeworkson.setTeacherId(teacherIdInteger);
        thomeworkson.setStudentId(studentIdInteger);
        thomeworkson.setFlagReply(flagReply);
        thomeworkson.setFlagFinish(flagFinish);
        LOGGER.info("thomework1接收参数" + " " + thomeworkson);//日志打印
        int x = student1Service.sHomeWorkInsertSingle(thomeworkson);
        System.out.println("x="+x);
        if (x == 1) {
            String data = gson.toJson(thomeworkson);
            LOGGER.info("sHomeWorkInsertSingle接收参数" + " " + data);//日志打印
            return data;
        }
        String data = "{\"data\":\"学生插入教师布置的数据失败！\"}";
        return data;
    }

    @ResponseBody
    @RequestMapping(value="/sHomeWorkUpdateSingle", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String sHomeWorkUpdateSingle(HttpServletRequest request, Model model){
        //String homeworkcountString = request.getParameter("homework_count");
        String IdString = request.getParameter("id");
        Integer IdInteger = Integer.valueOf(IdString);
        Date date = new Date();
        String homeworkFinishTime = date.toString();
        String homeworkContentString = request.getParameter("homeworkContent");
        String flagFinish = "1";
        HomeWorkSon thomeworkson = new HomeWorkSon();
        try {
            Integer flagFinish1 = DataCheck1.check4(flagFinish);
            thomeworkson.setFlagFinish(flagFinish1);
        }catch(Exception e) {
            return e.getMessage();
        }
        thomeworkson.setHomeworkContent(homeworkContentString);
        thomeworkson.setHomeworkWriteTime(homeworkFinishTime);
        thomeworkson.setId(IdInteger);
        System.out.println(flagFinish);
        student1Service.sHomeWorkUpdateSingle(thomeworkson);
        System.out.println(thomeworkson);
        String data = "{\"data\":\"作业完成！\"}";
        return data;
    }

    //请假模块
    @ResponseBody
    @RequestMapping(value="/sTakeLeaveInsert", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String sTakeLeaveInsert(HttpServletRequest request, Model model){
        HttpSession session = request.getSession();
        Student1 student3 = (Student1)session.getAttribute("Student1");
        Integer studentIdInteger = student3.getStudentId();
        Integer flagInteger = 0;
        String studentNameString = request.getParameter("studentName");
        String studentLeaveReasonString = request.getParameter("studentLeaveReason");
        String teacherIdString = request.getParameter("teacherId");
        Integer teacherIdInteger = Integer.parseInt(teacherIdString);
        Date date = new Date();
        String studentLeaveTimeString = date.toString();
        //if (StringUtils.isNotEmpty(studentIdString)){
        TakeLeaveStudent tstudenttakeleave =  new TakeLeaveStudent();
        tstudenttakeleave.setStudentId(studentIdInteger);
        tstudenttakeleave.setFlag(flagInteger);
        tstudenttakeleave.setStudentName(studentNameString);
        tstudenttakeleave.setTeacherId(teacherIdInteger);
        tstudenttakeleave.setStudentLeaveReason(studentLeaveReasonString);
        tstudenttakeleave.setStudentLeaveTime(studentLeaveTimeString);
        student1Service.sTakeLeaveInsert(tstudenttakeleave);
        LOGGER.info("tTeacherUpdateTakeLeave接收参数"+" " +tstudenttakeleave);//日志打印
        String data = gson.toJson(tstudenttakeleave) + "{\"data\":\"请假成功！\"}";
        return data;
        //}
        //String data = "{\"data\":\"请假失败！\"}";
        //return data;
    }

    @ResponseBody
    @RequestMapping(value="/sTakeLeaveSelect", method= RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String sTakeLeaveSelect(HttpServletRequest request, Model model){
        HttpSession session = request.getSession();
        Student1 student3 = (Student1)session.getAttribute("Student1");
        Integer studentIdInteger = student3.getStudentId();
        System.out.println(studentIdInteger+"------------------");
        List<TakeLeaveStudent> tstudenttake_leavelist = student1Service.sTakeLeaveSelect(studentIdInteger);
        String data = gson.toJson(tstudenttake_leavelist);
        LOGGER.info("tTeacherUpdateTakeLeave接收参数"+" " +tstudenttake_leavelist);//日志打印
        return data;
    }


    //文件模块
    private static final String NULL_FILE = "";

    @Value("${define.nginx.path}")
    private String nginxPath;

    /**
     * 文件查看
     * @param request
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("showFiles")
    public String showFiles(HttpServletRequest request,Integer studentId) throws Exception {
        HttpSession session = request.getSession();
        Student1 student3 = (Student1)session.getAttribute("Student1");
        studentId = student3.getStudentId();
        List<FilePath> filepaths = student1Service.showFiles(studentId);
        String[] Parameter = new String[]{"id","filePath","uploadName","uploadTime","uploadId"};
        String jsonString = ObjtoLayJson.ListtoJson(filepaths,Parameter);
        LOGGER.info("文件模块接收参数showFiles"+" " +jsonString);
//        String json = gson.toJson(filepaths);
//        return json;
        return jsonString;
    }

    /**
     * 文件下载
     * @param response
     * @param model
     * @return
     */
    @RequestMapping(value="/download", method=RequestMethod.POST,produces = "text/plain;charset=utf-8")
    public String  testDownload(HttpServletRequest request , HttpServletResponse response , Model model) {
        System.out.println("下载模块进来了00------------------------");
        String filePath1 = request.getParameter("filePath");
        System.out.println(nginxPath + filePath1 + "**************");
        student1Service.download(response,filePath1,model);

        //成功后返回成功信息
        model.addAttribute("result","下载成功");
        return "employee/EmployeeDownloadFile";
    }
}
