package cn.zcbigdata.mybitsdemo.entity;

public class DataCheck1 {
    private Integer studentId;
    private Integer teacherId;
    private Integer flagReply;
    private Integer flagFinish;
    public static Integer check1(String studentId) throws Exception{//throws不稳定
        try {
            int x = Integer.parseInt(studentId);
            return x;
        }catch(Exception e) {
            throw new Exception("学生学号有问题");
        }
    }
    public static Integer check2(String teacherId) throws Exception{
        try {
            return Integer.parseInt(teacherId);
        }catch(Exception e) {
            throw new Exception("教师工号有问题");
        }
    }
    public static Integer check3(String flagReply) throws Exception{
        try {
            Integer x = Integer.parseInt(flagReply);
            return x;
        }catch(Exception e) {
            throw new Exception("教师回复标志有问题");
        }
    }
    public static Integer check4(String flagFinish) throws Exception{//throws不稳定
        try {
            Integer x = Integer.parseInt(flagFinish);
            return x;
        }catch(Exception e) {
            throw new Exception("学生完成作业标志有问题");
        }
    }

    public Integer getStudentId() {
        return studentId;
    }

    public void setStudentId(Integer studentId) {
        this.studentId = studentId;
    }

    public Integer getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(Integer teacherId) {
        this.teacherId = teacherId;
    }

    public Integer getFlagReply() {
        return flagReply;
    }

    public void setFlagReply(Integer flagReply) {
        this.flagReply = flagReply;
    }

    public Integer getFlagFinish() {
        return flagFinish;
    }

    public void setFlagFinish(Integer flagFinish) {
        this.flagFinish = flagFinish;
    }

    @Override
    public String toString() {
        return "DataCheck1{" +
                "studentId=" + studentId +
                ", teacherId=" + teacherId +
                ", flagReply=" + flagReply +
                ", flagFinish=" + flagFinish +
                '}';
    }
}
