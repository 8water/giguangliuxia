package cn.zcbigdata.mybitsdemo.entity;

public class TakeLeaveStudent {
    private Integer id;
    private Integer studentId;
    private String studentName;
    private String studentLeaveReason;
    private String studentLeaveTime;
    private Integer flag;
    private Integer teacherId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getStudentId() {
        return studentId;
    }

    public void setStudentId(Integer studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentLeaveReason() {
        return studentLeaveReason;
    }

    public void setStudentLeaveReason(String studentLeaveReason) {
        this.studentLeaveReason = studentLeaveReason;
    }

    public String getStudentLeaveTime() {
        return studentLeaveTime;
    }

    public void setStudentLeaveTime(String studentLeaveTime) {
        this.studentLeaveTime = studentLeaveTime;
    }

    public Integer getFlag() {
        return flag;
    }

    public void setFlag(Integer flag) {
        this.flag = flag;
    }

    public Integer getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(Integer teacherId) {
        this.teacherId = teacherId;
    }

    @Override
    public String toString() {
        return "TStudentTakeLeave{" +
                "id=" + id +
                ", studentId=" + studentId +
                ", studentName='" + studentName + '\'' +
                ", studentLeaveReason='" + studentLeaveReason + '\'' +
                ", stuentLeaveTime='" + studentLeaveTime + '\'' +
                ", flag=" + flag +
                ", teacherId=" + teacherId +
                '}';
    }
}
