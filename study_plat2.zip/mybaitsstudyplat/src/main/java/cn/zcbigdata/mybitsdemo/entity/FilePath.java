package cn.zcbigdata.mybitsdemo.entity;

public class FilePath {
    private Integer id;
    private String filePath;
    private String uploadName;
    private String uploadTime;
    private Integer uploadId;

    public Integer getUploadId() {
        return uploadId;
    }

    public void setUploadId(Integer uploadId) {
        this.uploadId = uploadId;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath == null ? null : filePath.trim();
    }

    public String getUploadName() {
        return uploadName;
    }

    public void setUploadName(String uploadName) {
        this.uploadName = uploadName;
    }

    public String getUploadTime() {
        return uploadTime;
    }

    public void setUploadTime(String uploadTime) {
        this.uploadTime = uploadTime;
    }

    @Override
    public String toString() {
        return "filePath{" +
                "id=" + id +
                ", filePath='" + filePath + '\'' +
                ", uploadName='" + uploadName + '\'' +
                ", uploadTime='" + uploadTime + '\'' +
                ", uploadId=" + uploadId +
                '}';
    }
}